# The look

Calm, dark, documentary. A flat 2D world with one subject doing one thing, while short bold text carries the facts. Motion should feel constant but never busy.

## Rules that matter most
- **Something changes every 1.5 to 3 seconds**, and it lands on the stressed word, within two frames.
- **One idea per beat.** Short captions, one number, one chip. The voice carries the sentence.
- **Keep the animal alive.** Always some `wave`. Use `bend` and `turn` keyframes when it changes direction.
- **Move the camera on every scene.** A slow zoom of 1.0 to 1.15, focused on the subject. Hard cuts on the beat are the default, and only fade for a change of chapter.
- **Depth tells the story.** Deeper means darker: raise `world.depth`, and use `beam` to light only the subject in the deep.

## Which moment gets which tool
| Moment | Use |
|---|---|
| Mystery or scale at the start | `look:"shadow"` against `world.sun`, with a shoal scattering |
| "Look at this part" | close-up with big `size`, `jaw` keyframe, `loop` |
| Going down | `depth` keyframes, `rain`, a `turn` nose-down, the `depth` gauge |
| A duration | `dial` |
| A big number | `count`, large, then a `seal` as the verdict |
| A list of facts | `facts`, the most shocking last with `hot` |
| How it senses | `world.mode:"dark"` with `sonic`, or `radar` |
| Finding prey | `radar`, then cut to the lit animal with `lock` |
| Loud or powerful | `shock`, `cam.shake`, `bar` with `count` |
| Size against something familiar | `person` or `diver` beside it, `scale`, `span` |
| Wrong idea | `cross` |

Use real relative sizes when two animals share a frame: pick one unit and scale both from their true lengths.

## Layout
- Captions sit at the bottom. Keep faces, jaws and numbers above them.
- In 16:9, split the frame: animal on one side, numbers on the other. In Arabic, numbers read well on the left with the animal on the right, or the reverse if the animal is swimming left.
- In 9:16, stack them: text high, animal in the middle, captions around y 1500.
- Fill `deep` with `sun`, `beam` and `shoal`, so no scene is an empty gradient.
- Other settings: use `desert`, `forest` or `night` and add `ground`.
