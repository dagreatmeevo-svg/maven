# Scene file

```json
{
  "format": "16:9", "fps": 30, "lang": "ar", "theme": "deep", "digits": "latin",
  "voice": "vo.mp3", "music": "bed.mp3", "musicDb": -20,
  "scenes": [
    { "from": 0, "to": 3.2, "vignette": 0.75,
      "world": { }, "cam": { },
      "stage": [ ], "hud": [ ] }
  ]
}
```

- **Coordinates:** 1920x1080 for 16:9 and 1080x1920 for 9:16, whatever the output size.
- **Times:** always seconds of the whole film, never relative to the scene.
- **Keyframes:** any number marked (k) can be a list `[[time, value, "curve"], ...]`. Curves: `soft` (default), `out`, `in`, `line`, `spring`.
- **`stage`** moves with the camera. **`hud`** is fixed to the screen. Items draw in list order.
- Every item accepts `from` and `to`, which default to the scene's. Many accept `out`, a time to fade away.

Other top-level fields: `caps` (uppercase English captions, default on), `font` (`lalezar` for all text), `grain` (default 0.012), `colors` (override `hot`, `cool`, `mark`, `good`, `ink`).

## `world`
| field | meaning |
|---|---|
| mode | `open` (default), `dark`, `radar`, `heat`, `paper` |
| depth (k) | 0 bright to 1 near black |
| shafts, shaftPower | light shafts, on by default when depth is below 0.78 |
| sun | `{x,y,r}` glowing backlight, good behind shadows (k) |
| beam | `{x,w}` spotlight from above (k) |
| ground, groundY | `"light"` or `"dark"` floor, and its height |
| surface | true draws a bright surface line at the top |
| motes | number of drifting particles, 0 for none |

## `cam`
`zoom` (k), `x` (k), `y` (k) set a point that stays still while the view zooms around it. `punch` is the zoom kick on the cut (default 0.06, 0 for the first scene). `shake` is `[{"t":8.7,"amp":11,"decay":2.3}]`.

## Cast (in `stage`)
`kind`: `sperm`, `shark`, `orca`, `fish`, `armorfish`, `eel`, `squid`, `octopus`, `jelly`, `diver`, `person`, `eggs`, `rock`, `shape`, `swimmer`.

Shared fields: `x y size turn op` (all k), `flip`, `drift:[vx,vy]`, `bob` (bobbing height, 0 for none), `phase`, `look` (`lit`, `shadow`, `radar`, `heat`, `ghost`), `fade`. Animals face right unless flipped; the squid's arms point right.

Swimmers (`sperm` to `eel`, and `swimmer`): `wave` (k) body swing, `bend` (k) curves the back, `jaw` (k) opening in degrees, `colors`.
Octopus: `wave` (k), `curl` (k) arms inward, `pale` (k) 0 to 1 fades its colour. Eggs: `n`, `seed`, `hatch` (k).

**New animal as data:**
```json
{ "kind": "swimmer", "x": 900, "y": 500, "rig": {
  "len": 500, "amp": 30, "pow": 1.8, "cycles": 1.1, "pace": 5,
  "up": [[0,6],[0.1,40],[0.4,70],[0.8,20],[1,8]], "lo": [[0,6],[0.1,30],[0.4,60],[0.8,16],[1,8]],
  "tail": { "shape": "crescent", "size": 1 },
  "colors": { "top": "#44525c", "side": "#6b7a84", "under": "#dfe3e2", "line": "#1e262c", "jaw": "#dfe3e2" },
  "belly": [0.05, 0.85, 0.3], "marks": ["gills"],
  "eye": { "u": 0.14, "v": 0.2, "r": 7 },
  "jaw": { "u": 0.22, "v": -0.6, "len": 110, "teeth": 8, "tilt": -2, "mouth": "#3a0f12" },
  "fins": [{ "u": 0.38, "v": 1, "shape": "sail", "size": 1, "tone": "top" }, { "u": 0.3, "v": -0.8, "shape": "paddle", "size": 0.7, "swing": 8 }]
} }
```
`up` and `lo` are `[position from snout to tail, half-height]`. `u` is along the body (0 to 1) and `v` across it (1 top, -1 bottom). Tails: `fluke`, `crescent`, `fan`. Fins: `paddle`, `sail`, `blade`, `side`, `nub`, or SVG path data. Marks: `wrinkles`, `scars`, `gills`, `scales`, `orca`, `plates`.

**Any prop as SVG paths:** `{"kind":"shape","x":900,"y":500,"parts":[{"d":"M-40 0L0-60L40 0Z","fill":"#c9a15a","stroke":"#222","width":3}]}`

## Stage effects
| kind | fields |
|---|---|
| shoal | `x y w h n size look color vx` · `flee:{t,x,y,dist}` scatters them from a point |
| bubbles | `x y` (k) `rise n life emitTo` |
| rain | `power` (k): streaks rushing past when diving |
| sonic | `x y` (k) `clicks:[times] spread turn speed width color` |
| shock | `x y` (k) `every speed emitTo color`: expanding rings |
| radar | `x y r spread speed`: use with `world.mode:"radar"` and `look:"radar"` |
| loop | `x y rx ry dur seed color width`: hand-drawn circle |
| lock | `x y r`: target rings |
| span | `x1 y1 x2 y2 label color`: size marker |

## HUD
Colours can be `hot`, `cool`, `mark`, `good`, `ink` or a hex value.

| kind | fields |
|---|---|
| line | caption, word by word: `words:[["كلمة",1.2],...]`, or `text` with optional `times`. Mark words `*hot*` or `_cool_`. Also `y size wrap out` |
| title | `text x y size color family` |
| tag | corner label: `text x y size` |
| badge | `text x y size check hot w`. In Arabic, x is the right edge |
| facts | `x y gap size w items:[{text,t,hot,check}]` |
| seal | stamped verdict: `text x y size color turn` |
| count | `value origin start dur pre post x y size color` |
| bar | `x y w h value start dur` |
| depth | `value origin start dur unit step px` |
| dial | `value start dur top bottom x y r color` |
| cross | `x y size color width` |
| scale | height lines: `lines:[{y,label}]` |
| dots | icon grid: `x y cols n cell rowH dur label lostFrom lostAt` |
| note | paper card: `x y w h head title turn` |
| ticks | checklist: `x y w title items:[{text,t}]` |
| fade | to `color` between `from` and `to`; `reverse` fades in |

## Render options
`--res 720|1080|1440|4k` · `--voice f` · `--music f` · `--music-db n` · `--from s --to s` · `--fps n` · `--workers n` · `--raw` (skip the -14 LUFS step) · `--sheet` · `--still t`
