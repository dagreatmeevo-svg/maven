#!/usr/bin/env node
/* Maven Animate renderer. (c) 2026 Maven. See rights/MAVEN-RIGHTS.txt
   node scripts/render.mjs film.json out.mp4 [--res 720|1080|1440|4k] [--voice vo.mp3] [--music bed.mp3] [--music-db -20]
        [--from s] [--to s] [--fps n] [--workers n] [--raw]
   node scripts/render.mjs film.json sheet.png --sheet          one still per scene
   node scripts/render.mjs film.json still.png --still 3.4      one frame at full size */
import { createRequire } from "node:module";
import { spawn, spawnSync } from "node:child_process";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const argv = process.argv.slice(2);
const opt = (name, fallback) => {
  const i = argv.indexOf("--" + name);
  if (i < 0) return fallback;
  const next = argv[i + 1];
  return next !== undefined && !next.startsWith("--") ? next : true;
};
const [scenePath, outPath] = argv;
if (!scenePath || !outPath || scenePath.startsWith("--")) {
  console.error("usage: render.mjs film.json out.mp4|sheet.png [--res 1080|1440|4k] [--voice f] [--music f] [--sheet] [--still t] [--workers n]");
  process.exit(1);
}

function playwright() {
  const req = createRequire(import.meta.url);
  const npmGlobal = spawnSync("npm root -g", { encoding: "utf8", shell: true }).stdout?.trim();
  const roots = [path.join(here, ".."), process.cwd(), ...(process.env.NODE_PATH || "").split(path.delimiter), npmGlobal].filter(Boolean);
  return req(req.resolve("playwright", { paths: roots }));
}

const scene = JSON.parse(fs.readFileSync(scenePath, "utf8"));
const RES = { 720: 720, 1080: 1080, 1440: 1440, "2k": 1440, 2160: 2160, "4k": 2160 };
const res = RES[String(opt("res", "1080")).toLowerCase()];
if (!res) { console.error("--res must be 720, 1080, 1440 or 4k"); process.exit(1); }
const fps = +opt("fps", scene.fps || 30);
const sceneDir = path.dirname(path.resolve(scenePath));

function ff(args, feed) {
  return new Promise((resolve, reject) => {
    const p = spawn("ffmpeg", ["-y", "-v", "error", ...args], { stdio: [feed ? "pipe" : "ignore", "inherit", "inherit"] });
    p.on("close", code => (code ? reject(new Error("ffmpeg exited with " + code)) : resolve()));
    if (feed) feed(p.stdin);
  });
}
function encoder() {
  for (const [name, flags] of [
    ["h264_nvenc", ["-preset", "p5", "-tune", "hq", "-rc", "vbr", "-cq", "17", "-b:v", "0"]],
    ["h264_videotoolbox", ["-q:v", "72"]],
  ]) {
    const test = spawnSync("ffmpeg", ["-v", "error", "-f", "lavfi", "-i", "color=black:s=640x360:d=0.1", "-c:v", name, "-f", "null", "-"]);
    if (test.status === 0) return { name, flags };
  }
  return { name: "libx264", flags: ["-preset", "veryfast", "-crf", "16"] };
}

const chromium = playwright().chromium;
const engine = pathToFileURL(path.join(here, "..", "engine", "index.html")).href;
async function openPage(shortSide) {
  const browser = await chromium.launch();
  const page = await browser.newPage();
  await page.goto(engine);
  await page.evaluate(() => MAVEN.ready());
  const info = await page.evaluate(([sc, r]) => MAVEN.load(sc, r), [scene, shortSide]);
  return { browser, page, info };
}
const reportWarnings = async page => {
  const unknown = await page.evaluate(() => MAVEN.warnings());
  if (unknown.length) console.warn("unknown kinds, drawn as nothing:", unknown.join(", "));
};
const started = Date.now();

if (opt("sheet", false)) {
  const { browser, page } = await openPage(360);
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "maven-"));
  const list = scene.scenes;
  for (const [i, sc] of list.entries()) {
    const b64 = await page.evaluate(t => MAVEN.shot(t, .9), sc.from + (sc.to - sc.from) * .7);
    fs.writeFileSync(path.join(dir, `s${String(i).padStart(3, "0")}.jpg`), Buffer.from(b64, "base64"));
  }
  await reportWarnings(page);
  await browser.close();
  const cols = Math.min(4, list.length), rows = Math.ceil(list.length / cols);
  await ff(["-i", path.join(dir, "s%03d.jpg"), "-vf", `tile=${cols}x${rows}`, "-frames:v", "1", outPath]);
  fs.rmSync(dir, { recursive: true });
  console.log("wrote", outPath);
  process.exit(0);
}

if (opt("still", false) !== false) {
  const { browser, page } = await openPage(res);
  const b64 = await page.evaluate(t => MAVEN.shot(t, 1), +opt("still"));
  await reportWarnings(page);
  await browser.close();
  const tmp = outPath + ".jpg";
  fs.writeFileSync(tmp, Buffer.from(b64, "base64"));
  await ff(["-i", tmp, "-frames:v", "1", outPath]);
  fs.rmSync(tmp);
  console.log("wrote", outPath);
  process.exit(0);
}

const length = scene.scenes[scene.scenes.length - 1].to;
const from = +opt("from", 0), to = Math.min(+opt("to", length), length);
const frames = Math.round((to - from) * fps);
const workers = Math.max(1, +opt("workers", Math.min(res >= 2000 ? 10 : 8, os.cpus().length - 2)));
const enc = encoder();
const picture = outPath.replace(/\.mp4$/i, "") + ".picture.mp4";
console.log(`${frames} frames, ${res}p, ${workers} workers, ${enc.name}`);

const slots = await Promise.all(Array.from({ length: workers }, () => openPage(res)));
const done = new Map();
let claimed = 0, written = 0, wake = () => {};
const nudge = () => { const w = wake; wake = () => {}; w(); };
const wait = () => new Promise(r => { const prior = wake; wake = () => { prior(); r(); }; });

const encoding = ff(["-f", "image2pipe", "-framerate", String(fps), "-c:v", "mjpeg", "-i", "-", "-c:v", enc.name, ...enc.flags, "-pix_fmt", "yuv420p", picture], stdin => {
  (async () => {
    while (written < frames) {
      if (!done.has(written)) { await wait(); continue; }
      const buf = done.get(written);
      done.delete(written);
      if (!stdin.write(buf)) await new Promise(r => stdin.once("drain", r));
      written++;
      if (written % fps === 0) process.stdout.write(`\rframe ${written}/${frames}`);
      nudge();
    }
    stdin.end();
  })();
});
await Promise.all(slots.map(async ({ page }) => {
  while (claimed < frames) {
    const f = claimed++;
    while (f - written > workers * 4) await wait();
    const b64 = await page.evaluate(t => MAVEN.shot(t), from + f / fps);
    done.set(f, Buffer.from(b64, "base64"));
    nudge();
  }
}));
await encoding;
await reportWarnings(slots[0].page);
await Promise.all(slots.map(s => s.browser.close()));
process.stdout.write("\n");
console.log(`picture done in ${((Date.now() - started) / 1000).toFixed(1)} s`);

const inScene = name => { const v = opt(name, scene[name]); return typeof v === "string" ? path.resolve(path.isAbsolute(v) || v === opt(name) ? "." : sceneDir, v) : null; };
const voice = inScene("voice"), music = inScene("music");
if (!voice && !music) {
  fs.renameSync(picture, outPath);
} else {
  const inputs = [], parts = [], names = [];
  let n = 0;
  const seconds = (to - from).toFixed(3);
  if (voice) { inputs.push("-ss", String(from), "-i", voice); parts.push(`[${n}:a]aresample=48000,apad,atrim=0:${seconds},asetpts=N/SR/TB[v${n}]`); names.push(`[v${n}]`); n++; }
  if (music) {
    inputs.push("-stream_loop", "-1", "-i", music);
    parts.push(`[${n}:a]aresample=48000,atrim=0:${seconds},asetpts=N/SR/TB,volume=${opt("music-db", scene.musicDb ?? -20)}dB,afade=t=out:st=${Math.max(0, to - from - .6)}:d=.6[v${n}]`);
    names.push(`[v${n}]`); n++;
  }
  const join = names.length > 1 ? `${parts.join(";")};${names.join("")}amix=inputs=${names.length}:duration=first:normalize=0,aformat=channel_layouts=stereo[mix]` : `${parts[0]};${names[0]}aformat=channel_layouts=stereo[mix]`;
  const mixWav = outPath.replace(/\.mp4$/i, "") + ".mix.wav";
  await ff([...inputs, "-filter_complex", join, "-map", "[mix]", "-c:a", "pcm_s16le", mixWav]);
  let filter = "anull";
  if (!opt("raw", false)) {           // two-pass, linear: -14 LUFS, -1.5 dBTP
    const log = spawnSync("ffmpeg", ["-hide_banner", "-nostats", "-i", mixWav, "-af", "loudnorm=I=-14:TP=-2:LRA=20:print_format=json", "-f", "null", "-"], { encoding: "utf8" }).stderr;
    const m = JSON.parse(log.slice(log.lastIndexOf("{"), log.lastIndexOf("}") + 1));
    filter = `loudnorm=I=-14:TP=-2:LRA=20:linear=true:measured_I=${m.input_i}:measured_TP=${m.input_tp}:measured_LRA=${m.input_lra}:measured_thresh=${m.input_thresh}:offset=${m.target_offset}:print_format=none,aresample=48000`;
  }
  await ff(["-i", picture, "-i", mixWav, "-map", "0:v:0", "-map", "1:a:0", "-af", filter, "-c:v", "copy", "-c:a", "aac", "-b:a", "256k", "-shortest", "-movflags", "+faststart", outPath]);
  fs.rmSync(mixWav);
  fs.rmSync(picture);
}
console.log(`wrote ${outPath} in ${((Date.now() - started) / 1000).toFixed(1)} s`);
