---
name: maven-animate
description: Maven Animate. Turns an Arabic or English script or voiceover into a narrated flat-vector animal or science explainer video, rendered in code from 1080p to 4K in seconds, with no paid image or video tools. Right-to-left Arabic captions, animals that bend as they swim, depth gauges, sonar, counters and word-by-word text. Use it when the user asks for an animated explainer, an animal facts video, an Arabic animation from a script or voice, or a Maven Animate video.
---

# Maven Animate

By **Maven**. Instagram [@maven.iqq](https://instagram.com/maven.iqq), YouTube **maveniqq**. See `rights/MAVEN-RIGHTS.txt`.

A film is one **scene file** (JSON). A canvas engine draws each frame in headless Chromium and ffmpeg encodes it. All art is code, so no images or footage are needed. The only outside tool is whatever makes the voice.

| Path | What it is |
|---|---|
| `engine/` | `core.js` (worlds, camera), `cast.js` (animals), `kit.js` (text and graphics) |
| `scripts/render.mjs` | scene file to MP4, contact sheet or still |
| `scripts/timestamps.py` | voice to word times, Arabic by default |
| `references/scene-format.md` | every field. Read before writing a scene |
| `references/look.md` | how these films should look and move. Read before planning shots |
| `references/ideas-ar.md` | finding a niche, ten ideas, and the script. Use when the user has no script |
| `examples/` | `octopus-ar.json` (Arabic) and `whale-en.json` (English) |

## Setup
Needs Node 18+, ffmpeg and Playwright's Chromium. Voice timing also needs Python with `faster-whisper`.
- `bash setup.sh` (macOS, Linux) or `powershell -ExecutionPolicy Bypass -File setup.ps1` (Windows).
- By hand: `npm install && npx playwright install chromium`, then `pip install -r requirements.txt`.

## Workflow
1. **Ask once** for anything missing: language (Arabic by default), format (`16:9` or `9:16`), quality (`1080`, `1440` or `4k`) and theme (`deep`, `desert`, `forest`, `night`). If there is no script yet, follow `references/ideas-ar.md` one stage at a time.
2. **Voice.** The user makes it in ElevenLabs or any tool and sends the file. Never invent timings when a voice exists.
3. **Timing.** `python scripts/timestamps.py vo.mp3 words.json --lang ar`. Whisper can misspell Arabic words, so keep the times and take the wording from the script. With no voice, allow about 2.2 Arabic or 2.6 English words per second.
4. **Plan.** Split the narration into beats of 1.5 to 3 seconds. Give each beat one clear event on its stressed word. Group beats into scenes of 1 to 4 seconds and don't use the same set-piece twice in a row. If an animal isn't in the cast, add it as a `swimmer` rig or `shape` in the scene file (see the format reference).
5. **Write the scene file.** All times are seconds of the film, straight from `words.json`, and any number can be keyframes.
6. **Check.** `node scripts/render.mjs film.json sheet.png --sheet`, then look at it. Check for overlaps, empty frames, text over faces, and that subjects are on screen. For a risky moment, use `--still 3.4 --res 720`.
7. **Render.** `node scripts/render.mjs film.json out.mp4 --res 4k --voice vo.mp3`. The sound is delivered at -14 LUFS. Add `--music bed.mp3 --music-db -20` only if the user asks for music. Give the user the MP4 and the scene file.

## Facts
Check surprising numbers against reliable sources when browsing is available. Mark estimates as estimates. Never invent animal behaviour, measurements or studies. Numbers on screen must match what the voice says.

## Arabic rules
- Set `"lang":"ar"`. Text then runs right to left, chips hang from the right, rulers and bars mirror themselves.
- Tashkeel and voice tags such as `[excited]` are removed from on-screen text automatically, so script text can be pasted in.
- Never break a word into letters, and never add letter spacing. The browser shapes the word as a whole.
- `"digits":"arab"` gives ٠١٢٣. The default is 123.

## Credit
Keep the `rights/` folder with every copy.
