/* Maven Animate: the cast
   (c) 2026 Maven. See rights/MAVEN-RIGHTS.txt
   Swimmers are built on a bending spine: a profile, a travelling wave and fins. A new animal can be plain data. */
(() => {
  const M = MAVEN, { TAU, RAD, clamp, mix, val, seeded, s, through, tint } = M;
  const shapes = {};
  const shape = d => (shapes[d] ||= new Path2D(d));

  function table(list) {
    const raw = [];
    for (let i = 0; i <= 100; i++) {
      const u = i / 100;
      for (let j = 0; j < list.length - 1; j++) {
        if (u <= list[j + 1][0]) { raw.push(mix(list[j][1], list[j + 1][1], (u - list[j][0]) / (list[j + 1][0] - list[j][0]))); break; }
      }
    }
    return raw.map((_, i) => {
      const w = Math.min(4, i, 100 - i);
      let sum = 0;
      for (let j = i - w; j <= i + w; j++) sum += raw[j];
      return sum / (2 * w + 1);
    });
  }

  const TAILS = {
    fluke: "M8-11C-30-22-70-70-134-94C-112-50-104-24-88 0C-104 24-112 50-134 94C-70 70-30 22 8 11Z",
    crescent: "M10-8C-20-30-62-90-116-128C-96-70-84-30-70-2C-82 20-92 44-104 74C-58 50-20 24 10 8Z",
    fan: "M8-8C-16-22-40-46-64-52C-56-24-54-10-52 0C-54 10-56 24-64 52C-40 46-16 22 8 8Z",
  };
  const FINS = {
    paddle: "M24-2C38 48 8 108-62 142C-70 90-54 36-36-8Z",
    sail: "M42 8C28-30-12-92-46-120C-46-70-54-26-64 8Z",
    blade: "M26 10C20-50 6-130-24-186C-40-120-50-46-52 10Z",
    side: "M28 0C26 34 2 78-46 104C-50 66-40 28-26-4Z",
    nub: "M18 4C12-14-6-30-26-34C-26-20-30-8-34 4Z",
  };

  const SPECIES = {
    sperm: {
      len: 780, amp: 40, pow: 2.2, cycles: 1.05, pace: 3.4, tail: { shape: "fluke" },
      up: [[0, 42], [.012, 76], [.05, 98], [.16, 112], [.34, 120], [.5, 112], [.6, 90], [.625, 106], [.66, 84], [.74, 62], [.85, 34], [.95, 16], [1, 11]],
      lo: [[0, 40], [.015, 62], [.06, 78], [.18, 100], [.34, 116], [.5, 104], [.62, 74], [.72, 52], [.85, 28], [.95, 15], [1, 11]],
      colors: { top: "#525a62", side: "#7b838a", under: "#b7bcbc", line: "#272d32", jaw: "#cfcec6" },
      belly: [.05, .76, .42], marks: ["wrinkles", "scars"],
      eye: { u: .25, v: -.46, r: 7 },
      jaw: { u: .29, v: -.86, len: 190, teeth: 10, tilt: -7, mouth: "#2a0f12" },
      fins: [{ u: .34, v: -.74, shape: "paddle", size: 1, swing: 11 }],
    },
    shark: {
      len: 660, amp: 30, pow: 1.7, cycles: 1.1, pace: 5.2, tail: { shape: "crescent" },
      up: [[0, 5], [.05, 30], [.18, 70], [.34, 86], [.52, 66], [.72, 32], [.9, 12], [1, 9]],
      lo: [[0, 5], [.05, 20], [.18, 54], [.34, 68], [.52, 50], [.72, 24], [.9, 10], [1, 9]],
      colors: { top: "#475560", side: "#62717c", under: "#e3e6e4", line: "#20282e", jaw: "#e3e6e4" },
      belly: [.03, .82, .28], marks: ["gills"],
      eye: { u: .13, v: .24, r: 6 },
      jaw: { u: .2, v: -.62, len: 118, teeth: 9, tilt: -2, mouth: "#3a0f12", under: true },
      fins: [{ u: .38, v: 1, shape: "sail", size: 1, tone: "top" }, { u: .7, v: 1, shape: "nub", size: 1.2, tone: "top" }, { u: .28, v: -.82, shape: "paddle", size: .78, swing: 7, tone: "top" }],
    },
    orca: {
      len: 680, amp: 34, pow: 2, cycles: 1.05, pace: 4, tail: { shape: "fluke", size: .85 },
      up: [[0, 16], [.04, 52], [.14, 82], [.32, 100], [.5, 92], [.72, 44], [.9, 16], [1, 10]],
      lo: [[0, 18], [.04, 44], [.14, 72], [.32, 94], [.5, 80], [.72, 36], [.9, 14], [1, 10]],
      colors: { top: "#101317", side: "#16191e", under: "#f1f1ee", line: "#000000", jaw: "#f1f1ee" },
      belly: [.02, .62, .32], marks: ["orca"],
      eye: { u: .13, v: .1, r: 5, light: true },
      fins: [{ u: .4, v: 1, shape: "blade", size: 1, tone: "side" }, { u: .24, v: -.8, shape: "paddle", size: .72, swing: 9, tone: "side" }],
    },
    fish: {
      len: 300, amp: 24, pow: 1.6, cycles: 1, pace: 9, tail: { shape: "fan", size: 1.3 },
      up: [[0, 8], [.08, 36], [.3, 62], [.55, 50], [.85, 18], [1, 11]],
      lo: [[0, 8], [.08, 30], [.3, 56], [.55, 44], [.85, 16], [1, 11]],
      colors: { top: "#4b6c7e", side: "#7f9cab", under: "#d5e2e8", line: "#2c3f49", jaw: "#d5e2e8" },
      belly: [.05, .86, .3], marks: ["scales"],
      eye: { u: .14, v: .18, r: 7 },
      fins: [{ u: .42, v: 1, shape: "nub", size: 1.5, tone: "top" }, { u: .3, v: -.5, shape: "side", size: .4, swing: 18, tone: "top" }],
    },
    armorfish: {
      len: 760, amp: 34, pow: 2.3, cycles: 1.05, pace: 3.9, tail: { shape: "crescent", size: .95 },
      up: [[0, 44], [.03, 84], [.12, 118], [.3, 128], [.4, 104], [.6, 72], [.82, 30], [1, 10]],
      lo: [[0, 40], [.03, 70], [.12, 98], [.3, 108], [.4, 86], [.6, 58], [.82, 26], [1, 10]],
      colors: { top: "#4d5a5e", side: "#6e7b7c", under: "#a9b2a8", line: "#20282a", jaw: "#c6bda3" },
      belly: [.42, .92, .3], marks: ["plates"],
      eye: { u: .15, v: .3, r: 11, ring: "#c6bda3" },
      jaw: { u: .27, v: -.8, len: 195, blade: true, tilt: -5, mouth: "#260d10" },
      fins: [{ u: .55, v: 1, shape: "sail", size: .72, tone: "top" }, { u: .44, v: -.8, shape: "side", size: 1, swing: 10, tone: "top" }],
    },
    eel: {
      len: 900, amp: 62, pow: .85, cycles: 1.7, pace: 6, tail: { shape: "fan", size: .8 },
      up: [[0, 10], [.05, 30], [.3, 36], [.7, 30], [.95, 12], [1, 6]],
      lo: [[0, 10], [.05, 26], [.3, 34], [.7, 28], [.95, 12], [1, 6]],
      colors: { top: "#3d4a33", side: "#5f6e45", under: "#c6c98e", line: "#1f2719", jaw: "#c6c98e" },
      belly: [.05, .95, .3], marks: [],
      eye: { u: .05, v: .2, r: 6 },
      fins: [],
    },
  };
  const ready = sp => { if (!sp._up) { sp._up = table(sp.up); sp._lo = table(sp.lo); } return sp; };

  function tones(colors, look) {
    if (look === "shadow") { const d = s.pal.shadow; return { top: d, side: d, under: d, line: d, jaw: d, flat: true }; }
    if (look === "radar") { const d = "#06240f"; return { top: d, side: d, under: d, line: s.pal.sonar, jaw: d, flat: true, edge: s.pal.sonar }; }
    if (look === "heat") return { top: "#7a3316", side: "#c8682f", under: "#f0a05a", line: "#512008", jaw: "#f0a05a" };
    if (look === "ghost") return { top: "#7d868b", side: "#9aa3a8", under: "#c3c9cc", line: "#5e666b", jaw: "#c3c9cc" };
    return colors;
  }

  function finish(c, t, fill) {
    c.fillStyle = fill;
    if (t.edge) {
      c.strokeStyle = M.alpha(t.edge, .2); c.lineWidth = 12; c.lineJoin = "round"; c.stroke();
      c.fill();
      c.strokeStyle = t.edge; c.lineWidth = 3.5; c.stroke();
    } else c.fill();
  }

  function swim(sp, a, t) {
    ready(sp);
    const c = s.c, look = a.look || "lit", T = tones(a.colors || sp.colors, look);
    const L = sp.len, wv = val(a.wave, t, 1), bd = val(a.bend, t, 0), ph = t * sp.pace + (a.phase || 0);
    const mid = u => [L * (.5 - u), wv * sp.amp * Math.pow(u, sp.pow) * Math.sin(TAU * sp.cycles * u - ph) + bd * L * .22 * u * u];
    const across = u => {
      const p = mid(Math.max(0, u - .01)), q = mid(Math.min(1, u + .01)), tx = q[0] - p[0], ty = q[1] - p[1], h = Math.hypot(tx, ty) || 1;
      return [-ty / h, tx / h];
    };
    const at = (u, v) => {
      u = clamp(u);
      const m = mid(u), n = across(u), h = (v >= 0 ? sp._up : sp._lo)[Math.round(u * 100)];
      return [m[0] + n[0] * v * h, m[1] + n[1] * v * h];
    };
    const N = 56, us = Array.from({ length: N + 1 }, (_, i) => i / N);
    const fin = (f, behind) => {
      if (!!f.back !== behind) return;
      const [x, y] = at(f.u, f.v);
      c.save();
      c.translate(x, y);
      c.rotate(((f.turn || 0) + Math.sin(t * (f.rate || 2.4)) * (f.swing || 0)) * RAD);
      c.scale(f.size || 1, f.size || 1);
      c.fillStyle = T[f.tone || "top"];
      const p = shape(FINS[f.shape] || f.shape);
      if (T.edge) { c.strokeStyle = T.edge; c.lineWidth = 3.5; c.stroke(p); }
      c.fill(p);
      c.restore();
    };

    if (sp.tail) {
      const end = mid(1), near = mid(.97), flap = Math.cos(TAU * sp.cycles - ph), sz = sp.tail.size || 1;
      c.save();
      c.translate(end[0], end[1]);
      c.rotate(Math.atan2(end[1] - near[1], end[0] - near[0]) - Math.PI + flap * 16 * RAD);
      c.scale(sz, sz * (.66 + .34 * Math.abs(flap)));
      c.fillStyle = T.side;
      const p = shape(TAILS[sp.tail.shape] || sp.tail.shape);
      if (T.edge) { c.strokeStyle = T.edge; c.lineWidth = 3.5; c.stroke(p); }
      c.fill(p);
      c.restore();
    }
    (sp.fins || []).forEach(f => fin(f, true));

    const body = new Path2D();
    through(body, us.map(u => at(u, 1)).concat(us.slice().reverse().map(u => at(u, -1))));
    const g = c.createLinearGradient(0, -130, 0, 80);
    g.addColorStop(0, T.top); g.addColorStop(1, T.side);
    c.fillStyle = T.flat ? T.side : g;
    if (T.edge) { c.strokeStyle = M.alpha(T.edge, .2); c.lineWidth = 12; c.lineJoin = "round"; c.stroke(body); }
    c.fill(body);
    if (T.edge) { c.strokeStyle = T.edge; c.lineWidth = 3.5; c.stroke(body); }

    if (!T.flat) {
      if (sp.belly) {
        const [u0, u1, v] = sp.belly, part = us.filter(u => u >= u0 && u <= u1);
        c.beginPath();
        through(c, part.map(u => at(u, -v)).concat(part.slice().reverse().map(u => at(u, -1))));
        c.fillStyle = T.under; c.globalAlpha *= .55; c.fill(); c.globalAlpha /= .55;
      }
      for (const m of sp.marks || []) marks[m]?.(c, at, T);
    }

    if (sp.jaw) {
      const J = sp.jaw, open = val(a.jaw, t, 1.5), [hx, hy] = at(J.u, J.v), ang = (open + J.tilt) * RAD;
      if (open > .4 && !T.flat) {
        const lip = at(.05, -1);
        c.beginPath(); c.moveTo(hx, hy); c.lineTo(lip[0], lip[1]); c.lineTo(hx + J.len * Math.cos(ang), hy + J.len * Math.sin(ang)); c.closePath();
        c.fillStyle = J.mouth; c.fill();
      }
      c.save();
      c.translate(hx, hy);
      c.rotate(ang);
      if (!T.flat && J.teeth) {
        c.fillStyle = "#fbf8ec";
        const step = (J.len - 40) / J.teeth;
        for (let i = 0; i < J.teeth; i++) { c.beginPath(); c.moveTo(34 + i * step, -4); c.lineTo(40 + i * step, -23); c.lineTo(46 + i * step, -4); c.fill(); }
      }
      if (!T.flat && J.blade) {
        c.fillStyle = "#e9e2c8";
        c.beginPath(); c.moveTo(70, -2); c.lineTo(J.len - 4, -48); c.lineTo(J.len - 2, 2); c.closePath(); c.fill();
      }
      c.beginPath();
      c.moveTo(-4, -5); c.bezierCurveTo(J.len * .32, -9, J.len * .68, -8, J.len, -4);
      c.bezierCurveTo(J.len + 10, 0, J.len + 6, 10, J.len - 6, 12);
      c.bezierCurveTo(J.len * .68, 20, J.len * .32, 22, -4, 18); c.closePath();
      finish(c, T, T.jaw);
      c.restore();
    }
    if (sp.eye && !T.flat) {
      const [ex, ey] = at(sp.eye.u, sp.eye.v);
      if (sp.eye.ring) { c.fillStyle = sp.eye.ring; c.beginPath(); c.arc(ex, ey, sp.eye.r + 7, 0, TAU); c.fill(); }
      if (sp.eye.light) { c.fillStyle = "#f1f1ee"; c.beginPath(); c.ellipse(ex - 18, ey - 8, 26, 11, 0, 0, TAU); c.fill(); }
      c.fillStyle = "#0a0a0a"; c.beginPath(); c.arc(ex, ey, sp.eye.r, 0, TAU); c.fill();
      c.fillStyle = "#fff"; c.beginPath(); c.arc(ex + sp.eye.r * .28, ey - sp.eye.r * .28, sp.eye.r * .28, 0, TAU); c.fill();
    }
    (sp.fins || []).forEach(f => fin(f, false));
  }

  const SCARS = (() => { const R = seeded(11); return Array.from({ length: 13 }, () => [.04 + R() * .24, .1 + R() * .82, .02 + R() * .04, (R() - .5) * .5]); })();
  const marks = {
    wrinkles(c, at, T) {
      c.strokeStyle = T.line; c.lineWidth = 2.6; c.lineCap = "round"; c.globalAlpha *= .34;
      for (let i = 0; i < 12; i++) {
        const u = .46 + i * .034, a = at(u, .72), b = at(u + .014, .24), d = at(u, -.2);
        c.beginPath(); c.moveTo(a[0], a[1]); c.quadraticCurveTo(b[0], b[1], d[0], d[1]); c.stroke();
      }
      c.globalAlpha /= .34;
    },
    scars(c, at) {
      c.strokeStyle = "#dfe3e3"; c.lineWidth = 2.4; c.lineCap = "round"; c.globalAlpha *= .42;
      for (const [u, v, du, dv] of SCARS) { const a = at(u, v), b = at(u + du, clamp(v + dv, -1, 1)); c.beginPath(); c.moveTo(a[0], a[1]); c.lineTo(b[0], b[1]); c.stroke(); }
      c.globalAlpha /= .42;
    },
    gills(c, at, T) {
      c.strokeStyle = T.line; c.lineWidth = 3; c.lineCap = "round";
      for (let i = 0; i < 5; i++) { const u = .2 + i * .022, a = at(u, .36), b = at(u + .012, -.1), d = at(u, -.42); c.beginPath(); c.moveTo(a[0], a[1]); c.quadraticCurveTo(b[0], b[1], d[0], d[1]); c.stroke(); }
    },
    scales(c, at, T) {
      c.strokeStyle = T.line; c.lineWidth = 1.6; c.globalAlpha *= .4;
      for (let i = 0; i < 9; i++) for (let j = -1; j <= 1; j++) { const [x, y] = at(.26 + i * .06, j * .5); c.beginPath(); c.arc(x, y, 9, -1, 1); c.stroke(); }
      c.globalAlpha /= .4;
    },
    orca(c, at) {
      c.fillStyle = "#f1f1ee";
      const a = at(.6, -.5);
      c.beginPath(); c.ellipse(a[0], a[1], 66, 22, -.12, 0, TAU); c.fill();
      const b = at(.44, .55);
      c.fillStyle = "#8f959b"; c.globalAlpha *= .75; c.beginPath(); c.ellipse(b[0], b[1], 48, 14, .1, 0, TAU); c.fill(); c.globalAlpha /= .75;
    },
    plates(c, at, T) {
      c.strokeStyle = T.line; c.lineWidth = 4; c.lineJoin = "round"; c.lineCap = "round";
      const seam = (pts) => { c.beginPath(); through(c, pts.map(([u, v]) => at(u, v)), false); c.stroke(); };
      seam([[.0, .1], [.12, -.1], [.28, -.3], [.38, -.9]]);
      seam([[.2, 1], [.21, .4], [.28, -.3]]);
      seam([[.36, 1], [.32, .4], [.28, -.3]]);
      seam([[.07, .95], [.1, .35], [.12, -.1]]);
      c.globalAlpha *= .3; c.fillStyle = "#dfe6dc";
      const a = at(.2, .7); c.beginPath(); c.ellipse(a[0], a[1], 50, 12, 0, 0, TAU); c.fill(); c.globalAlpha /= .3;
    },
  };

  function ribbon(c, pts, w0, w1) {
    const n = pts.length, up = [], lo = [];
    pts.forEach(([x, y], i) => {
      const a = pts[Math.max(0, i - 1)], b = pts[Math.min(n - 1, i + 1)], tx = b[0] - a[0], ty = b[1] - a[1], h = Math.hypot(tx, ty) || 1, r = mix(w0, w1, i / (n - 1)) / 2;
      up.push([x - (ty / h) * r, y + (tx / h) * r]);
      lo.push([x + (ty / h) * r, y - (tx / h) * r]);
    });
    through(c, up.concat(lo.reverse()));
  }

  const draws = {
    squid(a, t) {
      const c = s.c, radar = a.look === "radar", sonar = s.pal.sonar;
      const fill = radar ? "#06240f" : "#c5473d", light = radar ? sonar : "#ec8a72", dark = radar ? "#06240f" : "#7f251e";
      const T = { edge: radar ? sonar : null };
      c.rotate(Math.sin(t * 1.7) * 3 * RAD);
      for (let i = 0; i < 10; i++) {
        const long = i >= 8, ln = long ? 470 : 190 + ((i * 37) % 90), off = long ? (i === 8 ? -12 : 16) : -24 + (i % 8) * 7, pts = [];
        for (let j = 0; j < 15; j++) { const u = j / 14; pts.push([100 + ln * u, off * (1 + u * 1.5) + Math.sin(u * 5.5 - t * 4.6 + i * .9) * (6 + 34 * u)]); }
        c.beginPath(); ribbon(c, pts, long ? 9 : 15, long ? 3 : 1.6); finish(c, T, i % 2 ? dark : fill);
        if (long) { const e = pts[14]; c.fillStyle = light; c.beginPath(); c.ellipse(e[0], e[1], 26, 11, 0, 0, TAU); c.fill(); }
      }
      const f = Math.sin(t * 5) * 13;
      c.beginPath(); c.moveTo(-205, -8); c.lineTo(-292, -50 - f); c.lineTo(-300, 0); c.lineTo(-292, 50 + f); c.lineTo(-205, 8); c.closePath(); finish(c, T, dark);
      c.save(); c.scale(1, 1 + Math.sin(t * 5) * .05);
      c.fill(shape("M0 0"));
      c.beginPath(); c.moveTo(84, -40); c.bezierCurveTo(10, -58, -130, -52, -270, -8); c.lineTo(-296, 0); c.lineTo(-270, 8); c.bezierCurveTo(-130, 52, 10, 58, 84, 40); c.closePath(); finish(c, T, fill);
      c.restore();
      c.beginPath(); c.ellipse(102, 0, 44, 38, 0, 0, TAU); finish(c, T, fill);
      c.fillStyle = "#f6e7a8"; c.beginPath(); c.arc(108, -5, 19, 0, TAU); c.fill();
      c.fillStyle = "#0a0a0a"; c.beginPath(); c.arc(112, -5, 10, 0, TAU); c.fill();
    },
    octopus(a, t) {
      const c = s.c, pale = val(a.pale, t, 0), radar = a.look === "radar", shadow = a.look === "shadow";
      const paint = h => (shadow ? s.pal.shadow : radar ? "#06240f" : tint(h, "#d9cfc6", pale));
      const T = { edge: radar ? s.pal.sonar : null }, calm = val(a.wave, t, 1), curl = val(a.curl, t, .6);
      for (let i = 0; i < 8; i++) {
        const dir = mix(.16, .84, i / 7) * Math.PI, ln = 330 + ((i * 53) % 80), pts = [];
        for (let j = 0; j < 16; j++) {
          const u = j / 15, ang = dir + Math.sin(u * 4 - t * 2.1 + i * 1.3) * .32 * calm * u + (i < 4 ? 1 : -1) * curl * u * u;
          const prev = j ? pts[j - 1] : [Math.cos(dir) * 58, 52];
          pts.push(j ? [prev[0] + Math.cos(ang) * ln / 15, prev[1] + Math.sin(ang) * ln / 15] : prev);
        }
        c.beginPath(); ribbon(c, pts, 42, 5); finish(c, T, paint(i % 2 ? "#a63a30" : "#c5503f"));
        if (!radar && !shadow) {
          c.fillStyle = tint("#f0c2ad", "#e6ded7", pale);
          for (let j = 2; j < 14; j += 2) { c.beginPath(); c.arc(pts[j][0], pts[j][1], (1 - j / 16) * 8 + 1.5, 0, TAU); c.fill(); }
        }
      }
      const b = 1 + Math.sin(t * 1.5 * calm) * .035;
      c.save(); c.scale(b, 2 - b);
      c.beginPath(); c.moveTo(-94, 62); c.bezierCurveTo(-136, -14, -104, -158, 0, -166); c.bezierCurveTo(104, -158, 136, -14, 94, 62); c.bezierCurveTo(50, 92, -50, 92, -94, 62); c.closePath();
      finish(c, T, paint("#c5503f"));
      c.restore();
      if (!radar && !shadow) {
        c.fillStyle = tint("#e27a63", "#e6ded7", pale); c.globalAlpha *= .6;
        c.beginPath(); c.ellipse(-30, -100, 34, 46, -.4, 0, TAU); c.fill(); c.globalAlpha /= .6;
        for (const x of [-52, 52]) {
          c.fillStyle = tint("#f6e7a8", "#cfcabc", pale); c.beginPath(); c.arc(x, 8, 24, 0, TAU); c.fill();
          c.fillStyle = tint("#0a0a0a", "#8c8880", pale); c.beginPath(); c.roundRect(x - 13, 2, 26, 11, 5); c.fill();
        }
      }
    },
    jelly(a, t) {
      const c = s.c, T = { edge: a.look === "radar" ? s.pal.sonar : null }, p = Math.sin(t * 2.6), col = a.look === "radar" ? "#06240f" : "#c78be0";
      for (let i = 0; i < 9; i++) {
        const x0 = -78 + i * 19.5, pts = [];
        for (let j = 0; j < 12; j++) { const u = j / 11; pts.push([x0 * (1 - u * .3) + Math.sin(u * 6 - t * 3 + i) * 18 * u, 30 + u * (260 + i * 7) * (1 - p * .08)]); }
        c.beginPath(); ribbon(c, pts, 7, 1.5); finish(c, T, "#e7b8f5");
      }
      c.save(); c.scale(1 + p * .1, 1 - p * .1);
      c.beginPath(); c.moveTo(-112, 34); c.bezierCurveTo(-120, -70, -60, -118, 0, -118); c.bezierCurveTo(60, -118, 120, -70, 112, 34); c.quadraticCurveTo(0, 8, -112, 34); c.closePath();
      c.globalAlpha *= .9; finish(c, T, col); c.globalAlpha /= .9;
      c.restore();
    },
    diver(a, t) {
      const c = s.c, kick = Math.sin(t * 4 + (a.phase || 0)) * .22;
      const suit = a.look === "shadow" ? s.pal.shadow : "#2b2f36", tank = a.look === "shadow" ? s.pal.shadow : "#e8e8e8", flip = a.look === "shadow" ? s.pal.shadow : "#f2b705";
      for (const sign of [1, -1]) {
        c.save(); c.translate(-100, 6); c.rotate(kick * sign);
        c.fillStyle = suit; c.beginPath(); c.roundRect(-108, -11, 116, 22, 11); c.fill();
        c.fillStyle = flip; c.beginPath(); c.moveTo(-104, -9); c.lineTo(-206, -30 * sign - 4); c.lineTo(-198, 16 * sign); c.lineTo(-104, 10); c.fill();
        c.restore();
      }
      c.fillStyle = suit; c.beginPath(); c.roundRect(-112, -24, 216, 50, 24); c.fill();
      c.fillStyle = tank; c.beginPath(); c.roundRect(-64, -54, 138, 28, 14); c.fill();
      c.fillStyle = suit; c.beginPath(); c.arc(126, -6, 28, 0, TAU); c.fill();
      if (a.look !== "shadow") { c.fillStyle = "#6fd3e6"; c.beginPath(); c.roundRect(128, -19, 26, 18, 5); c.fill(); }
      c.strokeStyle = suit; c.lineWidth = 15; c.lineCap = "round"; c.beginPath(); c.moveTo(82, 12); c.lineTo(166 + Math.sin(t * 2) * 5, 34); c.stroke();
    },
    person(a, t) {
      const c = s.c, sh = a.look === "shadow", ink = sh ? s.pal.shadow : "#e8e4da", legs = sh ? s.pal.shadow : "#39414a", skin = sh ? s.pal.shadow : "#d8ae85", arm = Math.sin(t * 2.6) * .12;
      c.fillStyle = legs; c.beginPath(); c.roundRect(-25, 0, 21, 104, 9); c.roundRect(4, 0, 21, 104, 9); c.fill();
      c.fillStyle = ink; c.beginPath(); c.roundRect(-34, -112, 68, 124, 16); c.fill();
      c.save(); c.translate(32, -100); c.rotate(-.75 + arm); c.fillStyle = ink; c.beginPath(); c.roundRect(-9, -6, 18, 90, 9); c.fill(); c.restore();
      c.fillStyle = skin; c.beginPath(); c.arc(0, -146, 30, 0, TAU); c.fill();
    },
    eggs(a, t) {
      const c = s.c, n = a.n || 40, R = seeded(a.seed || 4), hatch = val(a.hatch, t, 0), sh = a.look === "shadow";
      for (let i = 0; i < n; i++) {
        const x = (R() - .5) * 340, y = R() * 170, sw = Math.sin(t * 1.4 + i) * 4;
        c.strokeStyle = sh ? s.pal.shadow : "rgba(240,235,215,.6)"; c.lineWidth = 2.5; c.beginPath(); c.moveTo(x, -6); c.quadraticCurveTo(x + sw, y * .5, x + sw * 2, y); c.stroke();
        c.fillStyle = sh ? s.pal.shadow : tint("#f2ead0", "#ffffff", hatch); c.beginPath(); c.ellipse(x + sw * 2, y + 15, 10, 16, 0, 0, TAU); c.fill();
        if (!sh) { c.fillStyle = "#3a2b20"; c.beginPath(); c.arc(x + sw * 2, y + 13, 3.4, 0, TAU); c.fill(); }
      }
    },
    rock(a) {
      const c = s.c, base = a.look === "shadow" ? s.pal.shadow : "#39444b";
      c.fillStyle = base;
      c.fill(shape("M-430 150C-420 40-340-70-200-86C-120-150 60-150 150-90C300-70 410 20 440 150Z"));
      if (a.look !== "shadow") { c.fillStyle = "#4b5860"; c.fill(shape("M-300 30C-220-50-120-90-40-92C-90-44-180-10-300 30ZM90-82C180-70 290-20 340 60C260 10 170-40 90-82Z")); }
    },
    /* Any prop as SVG path data: {"kind":"shape","parts":[{"d":"M0 0...","fill":"#fff"}]} */
    shape(a) {
      const c = s.c;
      for (const p of a.parts || []) {
        const path = shape(p.d);
        if (p.fill) { c.fillStyle = p.fill; c.fill(path); }
        if (p.stroke) { c.strokeStyle = p.stroke; c.lineWidth = p.width || 3; c.stroke(path); }
      }
    },
  };

  function stage(fn) {
    return (a, t) => {
      const op = val(a.op, t, 1) * M.clamp((t - a.from) / (a.fade ?? .001));
      if (op <= .003) return;
      const c = s.c, age = t - a.from;
      const x = val(a.x, t, s.W / 2) + (a.drift?.[0] || 0) * age, y = val(a.y, t, s.H / 2) + (a.drift?.[1] || 0) * age + Math.sin(t * 1.7 + (a.phase || 0)) * (a.bob ?? 5);
      const z = val(a.size, t, 1);
      c.save();
      c.globalAlpha *= op;
      c.translate(x, y);
      c.rotate(val(a.turn, t, 0) * RAD);
      c.scale(a.flip ? -z : z, z);
      fn(a, t);
      c.restore();
    };
  }
  for (const k in SPECIES) M.cast[k] = stage((a, t) => swim(SPECIES[k], a, t));
  for (const k in draws) M.cast[k] = stage(draws[k]);
  /* A new animal as data, inside a scene: {"kind":"swimmer","rig":{"len":500,"amp":30,...}} */
  M.cast.swimmer = stage((a, t) => swim(a.rig, a, t));
  M.species = SPECIES;
})();
