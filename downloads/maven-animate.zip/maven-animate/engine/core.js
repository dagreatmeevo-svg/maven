/* Maven Animate: core
   (c) 2026 Maven. Instagram @maven.iqq, YouTube maveniqq. See rights/MAVEN-RIGHTS.txt
   A frame depends only on its time, so frames can be drawn in any order, on any number of workers. */
window.MAVEN = (() => {
  const TAU = Math.PI * 2, RAD = Math.PI / 180;
  const clamp = (v, a = 0, b = 1) => (v < a ? a : v > b ? b : v);
  const mix = (a, b, k) => a + (b - a) * k;
  const curve = {
    line: k => k,
    out: k => 1 - (1 - k) ** 3,
    in: k => k ** 3,
    soft: k => (k < .5 ? 4 * k ** 3 : 1 - ((2 - 2 * k) ** 3) / 2),
    spring: k => 1 + 2.7 * (k - 1) ** 3 + 1.7 * (k - 1) ** 2,
  };
  /* A number, or keyframes [[time, value, "curve"], ...] in seconds of film time. */
  function val(v, t, fallback) {
    if (v === undefined || v === null) return fallback;
    if (!Array.isArray(v) || !Array.isArray(v[0])) return v;
    if (t <= v[0][0]) return v[0][1];
    for (let i = 1; i < v.length; i++) {
      if (t < v[i][0]) {
        const k = (t - v[i - 1][0]) / (v[i][0] - v[i - 1][0]);
        return mix(v[i - 1][1], v[i][1], (curve[v[i][2]] || curve.soft)(k));
      }
    }
    return v[v.length - 1][1];
  }
  function seeded(n) {
    let a = Math.imul(n + 1, 2654435761) >>> 0;
    return () => {
      a = (a + 0x6d2b79f5) >>> 0;
      let x = Math.imul(a ^ (a >>> 15), 1 | a);
      x ^= x + Math.imul(x ^ (x >>> 7), 61 | x);
      return ((x ^ (x >>> 14)) >>> 0) / 4294967296;
    };
  }
  const rgb = h => [1, 3, 5].map(i => parseInt(h.substr(i, 2), 16));
  const tint = (a, b, k) => {
    const A = rgb(a), B = rgb(b);
    return "#" + A.map((v, i) => Math.round(mix(v, B[i], k)).toString(16).padStart(2, "0")).join("");
  };
  const alpha = (h, a) => `rgba(${rgb(h).join(",")},${a})`;

  const THEMES = {
    deep: { sky: ["#1c5670", "#050d15"], shaft: "#cdeeff", mote: "#bcd8e8", sun: ["#f0fbff", "#7fd0f0", "#2a7fa8"], ground: "#c9b285", groundDark: "#0c181f", shadow: "#04080c" },
    desert: { sky: ["#e9a862", "#3a1b10"], shaft: "#ffe9c6", mote: "#ffdca8", sun: ["#fff7e2", "#ffc672", "#d4702a"], ground: "#c78e4e", groundDark: "#4a2a16", shadow: "#1a0d07" },
    forest: { sky: ["#3f7550", "#07130d"], shaft: "#e6ffd6", mote: "#dcf2b8", sun: ["#fbffe6", "#c5e68a", "#4d8a48"], ground: "#34563a", groundDark: "#0f1d12", shadow: "#050c07" },
    night: { sky: ["#23264e", "#04050d"], shaft: "#d6dcff", mote: "#c9d0ff", sun: ["#ffffff", "#bfc8ff", "#4a57b0"], ground: "#2b2f55", groundDark: "#0b0c1c", shadow: "#03040a" },
  };
  const INK = { ink: "#f2f6f8", hot: "#ff4a4d", cool: "#5fd0ff", good: "#3ecf6a", sonar: "#39ff6a", mark: "#f4e25a", chip: "#0f1820" };

  const s = { warned: new Set() };          // shared frame state
  const cast = {}, kit = {};

  function even(v) { return Math.round(v / 2) * 2; }

  function load(scene, shortSide) {
    s.scene = scene;
    s.wide = (scene.format || "16:9") !== "9:16";
    s.W = s.wide ? 1920 : 1080;
    s.H = s.wide ? 1080 : 1920;
    s.k = shortSide / (s.wide ? s.H : s.W);
    s.lang = scene.lang || "ar";
    s.rtl = s.lang === "ar";
    s.caps = scene.caps ?? s.lang !== "ar";
    s.digits = scene.digits || "latin";
    s.pal = { ...INK, ...THEMES[scene.theme || "deep"], ...(scene.colors || {}) };
    s.font = scene.font === "lalezar" ? "Lalezar" : "Plex";
    const cv = document.getElementById("film");
    cv.width = even(s.W * s.k);
    cv.height = even(s.H * s.k);
    s.cv = cv;
    s.c = cv.getContext("2d", { alpha: false });
    s.c.imageSmoothingQuality = "high";
    s.light = sprite(even(s.W / 8), even(s.H / 8));      // shafts are drawn tiny, then scaled up: soft edges for free
    s.vig = vignette();
    s.grainTile = noiseTile();
    s.dot = softDot();
    const R = seeded(13);
    s.motes = Array.from({ length: 160 }, () => [R() * s.W, R() * s.H, 6 + R() * 16, 1 + R() * 3, R() < .25, R() * 6]);
    const Q = seeded(7);
    s.shafts = Array.from({ length: 7 }, () => [Q() * s.W * 1.2 - 100, 70 + Q() * 150, 150 + Q() * 220, .5 + Q(), Q() * 6]);
    (scene.scenes || []).forEach(sc => {
      for (const list of [sc.stage || [], sc.hud || []]) for (const it of list) {
        if (it.from == null) it.from = sc.from;
        if (it.to == null) it.to = sc.to;
      }
    });
    return { width: cv.width, height: cv.height, length: scene.scenes[scene.scenes.length - 1].to };
  }

  function sprite(w, h) {
    const cv = document.createElement("canvas");
    cv.width = w; cv.height = h;
    return cv;
  }
  function vignette() {
    const cv = sprite(even(s.W / 4), even(s.H / 4)), g = cv.getContext("2d");
    const cx = cv.width / 2, cy = cv.height / 2;
    const r = g.createRadialGradient(cx, cy, Math.max(cx, cy) * .75, cx, cy, Math.hypot(cx, cy) * 1.08);
    r.addColorStop(0, "rgba(0,0,0,0)");
    r.addColorStop(1, "rgba(0,0,0,1)");
    g.fillStyle = r;
    g.fillRect(0, 0, cv.width, cv.height);
    return cv;
  }
  function noiseTile() {
    const cv = sprite(256, 256), g = cv.getContext("2d"), im = g.createImageData(256, 256), R = seeded(3);
    for (let i = 0; i < im.data.length; i += 4) { const v = R() * 255; im.data[i] = im.data[i + 1] = im.data[i + 2] = v; im.data[i + 3] = 255; }
    g.putImageData(im, 0, 0);
    return cv;
  }
  function softDot() {
    const cv = sprite(64, 64), g = cv.getContext("2d"), r = g.createRadialGradient(32, 32, 0, 32, 32, 32);
    r.addColorStop(0, "rgba(255,255,255,1)");
    r.addColorStop(1, "rgba(255,255,255,0)");
    g.fillStyle = r;
    g.fillRect(0, 0, 64, 64);
    return cv;
  }

  function world(sc, t) {
    const c = s.c, w = sc.world || {}, p = s.pal, W = s.W, H = s.H, mode = w.mode || "open", d = val(w.depth, t, .4);
    let top = tint(p.sky[0], p.sky[1], d * .85), low = p.sky[1];
    if (mode === "dark") { top = "#030507"; low = "#000000"; }
    if (mode === "radar") { top = "#050806"; low = "#020302"; }
    if (mode === "heat") { top = "#3a2160"; low = "#120a24"; }
    if (mode === "paper") { top = "#2a2622"; low = "#141210"; }
    const g = c.createLinearGradient(0, 0, 0, H);
    g.addColorStop(0, w.top || top);
    g.addColorStop(1, w.low || low);
    c.fillStyle = g;
    c.fillRect(-W, -H, W * 3, H * 3);
    if (w.sun) {
      const x = val(w.sun.x, t, W / 2), y = val(w.sun.y, t, 220), r = val(w.sun.r, t, 480) + Math.sin(t * 2) * 18;
      const q = c.createRadialGradient(x, y, 0, x, y, r);
      q.addColorStop(0, alpha(p.sun[0], 1));
      q.addColorStop(.35, alpha(p.sun[1], .7));
      q.addColorStop(1, alpha(p.sun[2], 0));
      c.fillStyle = q;
      c.fillRect(x - r, y - r, r * 2, r * 2);
    }
    const wantShafts = mode === "open" && (w.shafts ?? d < .78);
    if (wantShafts || w.beam) {
      const L = s.light, l = L.getContext("2d"), u = L.width / W;
      l.setTransform(1, 0, 0, 1, 0, 0);
      l.clearRect(0, 0, L.width, L.height);
      l.setTransform(u, 0, 0, u, 0, 0);
      if (wantShafts) {
        const base = (w.shaftPower ?? .13) * (1 - d * .6);
        for (const [x, wd, lean, pow, ph] of s.shafts) {
          const sk = lean + Math.sin(t * .4 + ph) * 40;
          l.fillStyle = alpha(p.shaft, base * pow);
          l.beginPath();
          l.moveTo(x, -20); l.lineTo(x + wd, -20); l.lineTo(x + wd + sk, H + 20); l.lineTo(x + sk - wd * .6, H + 20);
          l.fill();
        }
      }
      if (w.beam) {
        const x = val(w.beam.x, t, W / 2), wd = val(w.beam.w, t, 300);
        const b = l.createLinearGradient(0, 0, 0, H);
        b.addColorStop(0, alpha(p.shaft, .4));
        b.addColorStop(1, alpha(p.shaft, 0));
        l.fillStyle = b;
        l.beginPath();
        l.moveTo(x - 46, -20); l.lineTo(x + 46, -20); l.lineTo(x + wd, H); l.lineTo(x - wd, H);
        l.fill();
      }
      c.drawImage(L, 0, 0, W, H);
    }
    const count = mode === "paper" ? 0 : w.motes ?? 70;
    const col = mode === "radar" ? INK.sonar : p.mote;
    c.fillStyle = col;
    for (let i = 0; i < count && i < s.motes.length; i++) {
      const [mx, y0, sp, r, big, ph] = s.motes[i];
      const y = (((y0 - t * sp) % H) + H) % H, x = mx + Math.sin(t * .5 + ph) * 10;
      if (big) {
        c.globalAlpha = .1;
        const R = r * 5;
        c.drawImage(s.dot, x - R, y - R, R * 2, R * 2);
      } else {
        c.globalAlpha = .24;
        c.beginPath(); c.arc(x, y, r, 0, TAU); c.fill();
      }
    }
    c.globalAlpha = 1;
    if (w.ground) {
      const y = w.groundY ?? H - 180;
      c.fillStyle = w.ground === "dark" ? p.groundDark : p.ground;
      c.beginPath();
      c.moveTo(-W, H * 2);
      for (let x = -W; x <= W * 2; x += 60) c.lineTo(x, y + Math.sin(x * .0042) * 26 + Math.sin(x * .011 + 1) * 11);
      c.lineTo(W * 2, H * 2);
      c.fill();
    }
    if (w.surface) {
      c.fillStyle = "rgba(191,230,244,.32)";
      c.fillRect(-W, -H, W * 3, H + 60);
      c.fillStyle = "rgba(230,247,255,.5)";
      c.fillRect(-W, 58, W * 3, 6);
    }
  }

  function camera(sc, t) {
    const cam = sc.cam || {}, c = s.c;
    const punch = (cam.punch ?? .06) * Math.exp(-(t - sc.from) * 7);
    const z = val(cam.zoom, t, 1) + punch, x = val(cam.x, t, s.W / 2), y = val(cam.y, t, s.H / 2);
    let dx = 0, dy = 0;
    for (const h of cam.shake || []) {
      if (t >= h.t) {
        const a = h.amp * Math.exp(-(t - h.t) * (h.decay ?? 2.3));
        dx += Math.sin(t * 67) * a; dy += Math.cos(t * 53) * a;
      }
    }
    c.translate(x + dx, y + dy);
    c.scale(z, z);
    c.translate(-x, -y);
  }

  function place(it, t) {
    if (t < it.from || t >= it.to) return;
    const fn = cast[it.kind] || kit[it.kind];
    if (!fn) { s.warned.add(it.kind); return; }
    fn(it, t);
  }

  function pick(t) {
    const list = s.scene.scenes;
    for (const sc of list) if (t >= sc.from && t < sc.to) return sc;
    return list[list.length - 1];
  }

  function draw(t) {
    const c = s.c, sc = pick(t), k = s.k;
    c.setTransform(k, 0, 0, k, 0, 0);
    c.globalAlpha = 1;
    c.save();
    camera(sc, t);
    world(sc, t);
    for (const it of sc.stage || []) place(it, t);
    c.restore();
    c.globalAlpha = sc.vignette ?? .75;
    c.drawImage(s.vig, 0, 0, s.W, s.H);
    c.globalAlpha = 1;
    for (const it of sc.hud || []) place(it, t);
    const grain = s.scene.grain ?? .012;      // a trace of fixed noise stops dark gradients from banding
    if (grain > 0) {
      c.setTransform(1, 0, 0, 1, 0, 0);
      c.globalAlpha = grain;
      c.globalCompositeOperation = "overlay";
      c.fillStyle = c.createPattern(s.grainTile, "repeat");
      c.fillRect(0, 0, s.cv.width, s.cv.height);
      c.globalCompositeOperation = "source-over";
      c.globalAlpha = 1;
    }
  }

  function shot(t, quality = .96) {
    draw(t);
    return s.cv.toDataURL("image/jpeg", quality).slice(23);
  }

  async function ready() {
    await Promise.all(["400 30px Plex", "500 30px Plex", "700 30px Plex", "30px Lalezar"].map(f => document.fonts.load(f, "عربي Abc 123")));
  }

  /* Smooth curve through points. */
  function through(c, pts, closed = true) {
    const n = pts.length;
    const P = j => (closed ? pts[(j + n) % n] : pts[Math.max(0, Math.min(n - 1, j))]);
    c.moveTo(pts[0][0], pts[0][1]);
    for (let i = 0; i < (closed ? n : n - 1); i++) {
      const a = P(i - 1), b = P(i), d = P(i + 1), e = P(i + 2);
      c.bezierCurveTo(b[0] + (d[0] - a[0]) / 6, b[1] + (d[1] - a[1]) / 6, d[0] - (e[0] - b[0]) / 6, d[1] - (e[1] - b[1]) / 6, d[0], d[1]);
    }
    if (closed) c.closePath();
  }

  return { TAU, RAD, clamp, mix, curve, val, seeded, tint, alpha, s, cast, kit, load, ready, draw, shot, through, warnings: () => [...s.warned] };
})();
