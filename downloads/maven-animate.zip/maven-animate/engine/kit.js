/* Maven Animate: on-screen kit
   (c) 2026 Maven. See rights/MAVEN-RIGHTS.txt
   Arabic is first-class: text is shaped by the browser, placed word by word from the right, and always measured, never guessed. */
(() => {
  const M = MAVEN, { TAU, RAD, clamp, mix, curve, val, seeded, s, through, alpha } = M;
  const K = M.kit;
  const hasArabic = v => /[؀-ۿ]/.test(v);
  const clean = v => String(v).replace(/[ً-ْٰ]/g, "").replace(/\[[^\]]*\]/g, "").trim();     // no tashkeel or voice tags on screen
  const show = v => { const t = clean(v); return s.caps && !hasArabic(t) ? t.toUpperCase() : t; };
  const ARABIC_DIGITS = "٠١٢٣٤٥٦٧٨٩";
  const digits = v => (s.digits === "arab" ? String(v).replace(/\d/g, d => ARABIC_DIGITS[d]).replace(/,/g, "٬") : String(v));
  const count = v => digits(Math.round(v).toLocaleString("en-US"));
  const came = (it, t, d = .22) => {
    let a = curve.out(clamp((t - it.from) / d));
    if (it.out != null) a *= 1 - curve.out(clamp((t - it.out) / .25));
    return a;
  };
  function font(size, weight = 700, family) { s.c.font = `${weight} ${size}px ${family || s.font}`; }
  function say(v, x, y, size, o = {}) {
    const c = s.c, str = String(v);
    font(size, o.weight, o.family);
    c.direction = hasArabic(str) ? "rtl" : "ltr";
    c.textAlign = o.align || "center";
    c.textBaseline = "alphabetic";
    if (o.halo !== 0) {
      c.lineJoin = "round";
      c.strokeStyle = `rgba(0,0,0,${o.halo ?? .5})`;
      c.lineWidth = size * .13;
      c.strokeText(str, x, y);
    }
    c.fillStyle = o.color || s.pal.ink;
    c.fillText(str, x, y);
  }
  const wide = (v, size, weight = 700) => { font(size, weight); s.c.direction = hasArabic(v) ? "rtl" : "ltr"; return s.c.measureText(v).width; };
  const hue = name => s.pal[name] || name;

  /* Caption, word by word. "text" with *hot* and _cool_ words, and "times", or "words": [["كلمة", 1.2], ...]. */
  function parse(it) {
    if (it._w) return it._w;
    let list = it.words ? it.words.map(([w, at]) => [w, at]) : clean(it.text).split(/\s+/).map((w, i, all) => [w, it.times ? it.times[i] : mix(it.from, it.to - .3, i / all.length)]);
    it._w = list.map(([w, at]) => {
      let color = null, txt = w;
      if (/^\*.*\*$/.test(w)) { color = "hot"; txt = w.slice(1, -1); }
      else if (/^_.*_$/.test(w)) { color = "cool"; txt = w.slice(1, -1); }
      return { txt: show(txt), color, at };
    });
    return it._w;
  }
  K.line = (it, t) => {
    const c = s.c, size = it.size || (s.wide ? 74 : 82), gap = size * .34, words = parse(it), maxW = s.W * (it.wrap || .88), rtl = hasArabic(words.map(w => w.txt).join(""));
    const rows = [[]];
    let used = 0;
    for (const w of words) {
      w.w = wide(w.txt, size);
      if (used + w.w > maxW && rows[rows.length - 1].length) { rows.push([]); used = 0; }
      rows[rows.length - 1].push(w);
      used += w.w + gap;
    }
    const cx = val(it.x, t, s.W / 2), lh = size * 1.32;
    const base = (it.y ?? (s.wide ? 965 : 1500)) - (rows.length - 1) * lh;
    const leave = it.out != null ? 1 - curve.out(clamp((t - it.out) / .22)) : 1;
    rows.forEach((row, r) => {
      const total = row.reduce((a, w) => a + w.w, 0) + gap * (row.length - 1);
      let cur = rtl ? cx + total / 2 : cx - total / 2;
      for (const w of row) {
        const mid = rtl ? cur - w.w / 2 : cur + w.w / 2, k = (t - w.at) / .17;
        cur += (rtl ? -1 : 1) * (w.w + gap);
        if (k <= 0) continue;
        c.save();
        c.globalAlpha *= clamp(k * 2.4) * leave;
        c.translate(mid, base + r * lh);
        const z = mix(1.2, 1, curve.spring(clamp(k)));
        c.scale(z, z);
        say(w.txt, 0, 0, size, { color: w.color ? s.pal[w.color] : s.pal.ink });
        c.restore();
      }
    });
  };

  K.title = (it, t) => {
    const k = clamp((t - it.from) / .24), c = s.c;
    c.save(); c.globalAlpha *= came(it, t, .16);
    c.translate(val(it.x, t, s.W / 2), val(it.y, t, s.H / 2));
    const z = mix(1.25, 1, curve.spring(k)); c.scale(z, z);
    say(show(it.text), 0, 0, it.size || 150, { family: it.family || (s.lang === "ar" ? "Lalezar" : undefined), color: hue(it.color || "ink") });
    c.restore();
  };

  K.tag = (it, t) => {
    const c = s.c, size = it.size || 40, txt = show(it.text), W = wide(txt, size), rtl = hasArabic(txt);
    const x = it.x ?? (rtl ? s.W - 70 : 70), y = it.y ?? 94, a = came(it, t);
    c.save(); c.globalAlpha *= a;
    say(txt, x, y, size, { align: rtl ? "right" : "left" });
    c.fillStyle = s.pal.hot;
    const w = W * .55 * curve.out(clamp((t - it.from - .1) / .4));
    c.fillRect(rtl ? x - w : x, y + 12, w, 3.5);
    c.restore();
  };

  function chip(it, t, text, x, y, size, o) {
    const c = s.c, txt = show(text), rtl = hasArabic(txt), a = came(o, t), tw = wide(txt, size), pad = size * .72, tick = o.check ? size * 1.5 : 0, w = o.w || tw + pad * 2 + tick, h = size * 2;
    const left = (rtl ? x - w : x) + (1 - a) * (rtl ? 30 : -30);
    c.save(); c.globalAlpha *= a;
    c.fillStyle = o.hot ? "rgba(92,20,22,.94)" : alpha(s.pal.chip, .9);
    c.beginPath(); c.roundRect(left, y, w, h, size * .34); c.fill();
    say(txt, rtl ? left + w - pad : left + pad, y + h * .67, size, { align: rtl ? "right" : "left", color: o.hot ? "#ff8080" : s.pal.ink, halo: 0 });
    if (o.check) {
      const q = curve.spring(clamp((t - o.from - .22) / .28)), cx = rtl ? left + size * 1.05 : left + w - size * 1.05, cy = y + h / 2;
      c.translate(cx, cy); c.scale(q, q);
      c.fillStyle = s.pal.good; c.beginPath(); c.arc(0, 0, size * .55, 0, TAU); c.fill();
      c.strokeStyle = "#08311a"; c.lineWidth = size * .14; c.lineCap = "round"; c.beginPath(); c.moveTo(-size * .26, 0); c.lineTo(-size * .07, size * .22); c.lineTo(size * .3, -size * .22); c.stroke();
    }
    c.restore();
  }
  /* In Arabic, x is the chip's right edge. */
  K.badge = (it, t) => chip(it, t, it.text, it.x ?? (s.rtl ? s.W - 90 : 90), it.y ?? 860, it.size || 36, { ...it });
  K.facts = (it, t) => (it.items || []).forEach((f, i) => { if (t >= f.t) chip(it, t, f.text, it.x ?? (s.rtl ? s.W - 110 : 110), (it.y ?? 360) + i * (it.gap || 104), it.size || 38, { ...f, from: f.t, out: it.out, w: it.w }); });

  K.seal = (it, t) => {
    const k = clamp((t - it.from) / .25), c = s.c, size = it.size || 64, txt = show(it.text), w = wide(txt, size) + size * 1.1, h = size * 1.55, col = hue(it.color || "hot");
    const buzz = k < 1 ? 0 : Math.max(0, .25 - (t - it.from - .25)) * Math.sin(t * 90) * 10;
    c.save();
    c.globalAlpha *= clamp(k * 3) * .94;
    c.translate(val(it.x, t, s.W / 2) + buzz, val(it.y, t, s.H / 2));
    c.rotate((it.turn ?? -6) * RAD);
    const z = mix(1.6, 1, curve.spring(k)); c.scale(z, z);
    c.strokeStyle = col; c.lineWidth = 5.5; c.strokeRect(-w / 2, -h / 2, w, h);
    say(txt, 0, size * .36, size, { color: col, halo: 0 });
    c.restore();
  };

  K.count = (it, t) => {
    const k = curve.out(clamp((t - (it.start ?? it.from)) / (it.dur || 1))), v = mix(it.origin || 0, it.value, k), c = s.c;
    c.save(); c.globalAlpha *= came(it, t);
    const num = (it.pre || "") + count(v) + (it.post ? " " + it.post : "");
    say(num, val(it.x, t, s.W / 2), val(it.y, t, s.H / 2), it.size || 180, { color: hue(it.color || "ink") });
    c.restore();
  };

  K.bar = (it, t) => {
    const c = s.c, x = it.x ?? 560, y = it.y ?? 600, w = it.w ?? 800, h = it.h ?? 28, k = curve.soft(clamp((t - (it.start ?? it.from) - .1) / (it.dur || 1.2))) * (it.value ?? 1);
    c.save(); c.globalAlpha *= came(it, t);
    c.fillStyle = "rgba(255,255,255,.08)"; c.beginPath(); c.roundRect(x, y, w, h, h / 2); c.fill();
    const g = s.rtl ? c.createLinearGradient(x + w, 0, x, 0) : c.createLinearGradient(x, 0, x + w, 0);
    g.addColorStop(0, "#3ecf6a"); g.addColorStop(.55, "#f2c94c"); g.addColorStop(1, "#e5383b");
    c.fillStyle = g;
    const fill = Math.max(h, w * k);
    c.beginPath(); c.roundRect(s.rtl ? x + w - fill : x, y, fill, h, h / 2); c.fill();
    c.restore();
  };

  /* Depth ruler with a live number. */
  K.depth = (it, t) => {
    const c = s.c, d = mix(it.origin || 0, it.value, curve.soft(clamp((t - (it.start ?? it.from)) / (it.dur || 1.5)))), mid = s.H / 2, unit = it.unit || (s.rtl ? "م" : "M"), step = it.step || 250, px = (it.px || 115) / step;
    const left = s.rtl, ruler = left ? 30 : s.W - 150;
    c.save(); c.globalAlpha *= came(it, t, .3);
    for (let m = 0; m <= it.value + step * 2; m += step) {
      const y = mid + (m - d) * px;
      if (y < -30 || y > s.H + 30) continue;
      const big = m % (step * 2) === 0;
      c.fillStyle = `rgba(255,255,255,${big ? .9 : .45})`;
      c.fillRect(left ? ruler : ruler + (big ? 0 : 30), y - 2, big ? 120 : 90, big ? 4 : 2.5);
      if (big) say(count(m), left ? ruler + 138 : ruler - 18, y + 11, 32, { align: left ? "left" : "right", weight: 500 });
    }
    const hot = d > it.value - 10, arrow = left ? ruler + 262 : ruler - 122, dirn = left ? -1 : 1;
    c.fillStyle = s.pal.hot;
    c.beginPath(); c.moveTo(arrow, mid); c.lineTo(arrow - 34 * dirn, mid - 22); c.lineTo(arrow - 34 * dirn, mid + 22); c.fill();
    const numX = left ? arrow + 70 : arrow - 200, shown = count(Math.round(d / 10) * 10), uW = wide(unit, 74);
    if (left) {            // Arabic reads number first, so the unit sits to its left
      say(unit, numX, mid + 37, 74, { align: "left" });
      say(shown, numX + uW + 24, mid + 37, 150, { align: "left", color: hot ? s.pal.hot : s.pal.ink });
    } else {
      say(shown, numX, mid + 37, 150, { align: "right", color: hot ? s.pal.hot : s.pal.ink });
      say(unit, numX + 20, mid + 37, 74, { align: "left" });
    }
    c.restore();
  };

  /* Circular timer: value counts up as the ring fills. */
  K.dial = (it, t) => {
    const c = s.c, x = it.x ?? 1400, y = it.y ?? 470, r = it.r ?? 205, k = curve.out(clamp((t - (it.start ?? it.from)) / (it.dur || 1.15))), col = hue(it.color || "cool");
    c.save(); c.globalAlpha *= came(it, t);
    c.fillStyle = alpha(s.pal.chip, .85); c.beginPath(); c.arc(x, y, r, 0, TAU); c.fill();
    c.lineWidth = 22; c.strokeStyle = "rgba(255,255,255,.12)"; c.beginPath(); c.arc(x, y, r, 0, TAU); c.stroke();
    c.strokeStyle = col; c.lineCap = "round"; c.beginPath();
    if (s.rtl) c.arc(x, y, r, -Math.PI / 2, -Math.PI / 2 - TAU * k + 1e-4, true); else c.arc(x, y, r, -Math.PI / 2, -Math.PI / 2 + TAU * k - 1e-4);
    c.stroke();
    if (it.top) say(show(it.top), x, y - 72, 36, { weight: 500 });
    say(count(k * it.value), x, y + 56, 150);
    if (it.bottom) say(show(it.bottom), x, y + 112, 36, { weight: 500 });
    c.restore();
  };

  /* Hand-drawn loop that draws itself around something. */
  K.loop = (it, t) => {
    const k = curve.out(clamp((t - it.from) / (it.dur || .4)));
    if (k <= 0) return;
    const c = s.c, R = seeded(it.seed || 3), n = 26, pts = [], rx = it.rx || 120, ry = it.ry || rx;
    for (let i = 0; i <= n; i++) {
      const a = -2 + (i / n) * TAU * 1.1, w = 1 + (R() - .5) * .05 + (i / n) * .05;
      pts.push([it.x + Math.cos(a) * rx * w, it.y + Math.sin(a) * ry * w]);
    }
    const show = pts.slice(0, Math.max(2, Math.ceil(n * k) + 1));
    c.save(); c.globalAlpha *= it.out != null ? 1 - clamp((t - it.out) / .25) : 1;
    c.strokeStyle = hue(it.color || "mark"); c.lineWidth = it.width || 8; c.lineCap = "round"; c.lineJoin = "round";
    c.beginPath(); through(c, show, false); c.stroke();
    c.restore();
  };

  K.lock = (it, t) => {
    const c = s.c, k = curve.out(clamp((t - it.from) / .4)), r = mix(it.r * 1.8, it.r, k);
    c.save(); c.globalAlpha *= k * .9; c.strokeStyle = "#e6eef2";
    c.lineWidth = 3.5; c.beginPath(); c.arc(it.x, it.y, r, 0, TAU); c.stroke();
    c.lineWidth = 1.5; c.globalAlpha *= .55; c.beginPath(); c.arc(it.x, it.y, r * 2.3, 0, TAU); c.stroke();
    c.restore();
  };

  K.cross = (it, t) => {
    const c = s.c, z = it.size || 90, a = curve.out(clamp((t - it.from) / .16)), b = curve.out(clamp((t - it.from - .14) / .16));
    c.save(); c.strokeStyle = hue(it.color || "hot"); c.lineWidth = it.width || 13; c.lineCap = "round";
    c.beginPath(); c.moveTo(it.x - z, it.y - z); c.lineTo(mix(it.x - z, it.x + z, a), mix(it.y - z, it.y + z, a)); c.stroke();
    if (b > 0) { c.beginPath(); c.moveTo(it.x + z, it.y - z); c.lineTo(mix(it.x + z, it.x - z, b), mix(it.y - z, it.y + z, b)); c.stroke(); }
    c.restore();
  };

  /* Size marker between two points. */
  K.span = (it, t) => {
    const c = s.c, k = curve.out(clamp((t - it.from) / .5)), x = mix(it.x1, it.x2, k), y = mix(it.y1, it.y2, k);
    c.save(); c.strokeStyle = hue(it.color || "mark"); c.lineWidth = 5; c.lineCap = "round";
    c.beginPath(); c.moveTo(it.x1, it.y1); c.lineTo(x, y); c.stroke();
    const nx = -(it.y2 - it.y1), ny = it.x2 - it.x1, h = Math.hypot(nx, ny) || 1;
    for (const [px, py] of [[it.x1, it.y1], [x, y]]) { c.beginPath(); c.moveTo(px + nx / h * 16, py + ny / h * 16); c.lineTo(px - nx / h * 16, py - ny / h * 16); c.stroke(); }
    if (it.label) { c.globalAlpha *= k; say(show(it.label), (it.x1 + it.x2) / 2, Math.max(it.y1, it.y2) + 62, 44, { color: hue(it.color || "mark") }); }
    c.restore();
  };

  /* Height lines for size comparisons. */
  K.scale = (it, t) => {
    const c = s.c;
    c.save(); c.globalAlpha *= came(it, t);
    for (const l of it.lines || []) {
      c.fillStyle = "rgba(255,255,255,.14)"; c.fillRect(0, l.y, s.W, 2.5);
      say(digits(l.label), s.rtl ? s.W - 34 : 34, l.y - 12, 30, { align: s.rtl ? "right" : "left", weight: 500 });
    }
    c.restore();
  };

  const FISH = new Path2D("M42 0C28-17-12-20-28 0L-50-17L-44 0L-50 17L-28 0C-12 20 28 17 42 0Z");
  /* A grid of icons that fills up; "lost" dims the last ones. */
  K.dots = (it, t) => {
    const c = s.c, cols = it.cols || 12, n = it.n || 60, cw = it.cell || 58, ch = it.rowH || 42, x0 = it.x ?? 300, y0 = it.y ?? 300, shown = Math.floor(n * curve.soft(clamp((t - it.from - .15) / (it.dur || 2)))), lost = it.lostAt != null ? clamp((t - it.lostAt) / 1) : 0;
    c.save(); c.globalAlpha *= came(it, t);
    for (let i = 0; i < shown; i++) {
      const col = s.rtl ? cols - 1 - (i % cols) : i % cols, gone = i >= (it.lostFrom ?? Infinity) && lost > 0;
      c.save();
      c.translate(x0 + col * cw, y0 + Math.floor(i / cols) * ch);
      c.scale(.56, .56);
      c.fillStyle = gone ? M.tint("#e8eef2", "#5a1a1e", lost) : "#e8eef2"; c.globalAlpha *= gone ? 1 - lost * .6 : .95;
      c.fill(FISH);
      c.restore();
    }
    if (it.label) say(show(it.label), x0 + (cols - 1) * cw / 2, y0 - 66, 42);
    c.restore();
  };

  K.note = (it, t) => {
    const a = came(it, t), c = s.c, w = it.w || 620, h = it.h || 700, x = it.x ?? s.W / 2, y = (it.y ?? s.H / 2) + (1 - a) * 30;
    c.save(); c.globalAlpha *= a; c.translate(x, y); c.rotate((it.turn ?? -1) * RAD);
    c.fillStyle = "#e7e3d8"; c.fillRect(-w / 2, -h / 2, w, h);
    if (it.head) say(show(it.head), 0, -h / 2 + 76, 30, { color: "#5b5b55", halo: 0, weight: 500 });
    String(it.title || "").split("\n").forEach((l, i) => say(show(l), 0, -h / 2 + 170 + i * 66, 54, { color: "#26262a", halo: 0 }));
    c.fillStyle = "rgba(154,150,141,.55)";
    for (let i = 0; i < 6; i++) { const lw = (w - 120) * (i % 3 === 2 ? .6 : 1); c.beginPath(); c.roundRect(s.rtl ? w / 2 - 60 - lw : -w / 2 + 60, -h / 2 + 310 + i * 46, lw, 11, 5); c.fill(); }
    c.restore();
  };

  K.ticks = (it, t) => {
    const c = s.c, w = it.w || 680, items = it.items || [], x = it.x ?? (s.W - w) / 2, y = it.y ?? 330, rtl = s.rtl, row = 84, size = 44;
    c.save(); c.globalAlpha *= came(it, t);
    c.fillStyle = alpha(s.pal.chip, .88); c.beginPath(); c.roundRect(x, y, w, items.length * row + 124, 18); c.fill();
    if (it.title) say(show(it.title), rtl ? x + w - 40 : x + 40, y + 70, 38, { align: rtl ? "right" : "left", color: s.pal.hot });
    items.forEach((m, i) => {
      const yy = y + 124 + i * row, bx = rtl ? x + w - 80 : x + 40, on = m.t != null ? curve.spring(clamp((t - m.t) / .25)) : 0;
      c.strokeStyle = "#e9eef2"; c.lineWidth = 3.5; c.strokeRect(bx, yy, 40, 40);
      if (on > 0) { c.save(); c.translate(bx + 20, yy + 20); c.scale(on, on); c.strokeStyle = s.pal.good; c.lineWidth = 7; c.lineCap = "round"; c.beginPath(); c.moveTo(-12, 0); c.lineTo(-4, 11); c.lineTo(15, -14); c.stroke(); c.restore(); }
      say(show(m.text), rtl ? bx - 26 : bx + 66, yy + 35, size, { align: rtl ? "right" : "left", weight: 500, halo: 0 });
    });
    c.restore();
  };

  K.fade = (it, t) => {
    const c = s.c, k = clamp((t - it.from) / ((it.to - it.from) || .3));
    c.fillStyle = it.color || "#000"; c.globalAlpha = it.reverse ? 1 - k : k;
    c.fillRect(0, 0, s.W, s.H); c.globalAlpha = 1;
  };

  /* ---- things that live in the world ---- */
  const FLEET = (() => { const R = seeded(5); return Array.from({ length: 120 }, () => [R() - .5, R() - .5, R() * TAU, R() * .4 + .6, R() * TAU]); })();
  K.shoal = (it, t) => {
    const c = s.c, n = Math.min(it.n || 30, 120), fl = it.flee, k = fl ? curve.out(clamp((t - fl.t) / .7)) : 0, col = it.look === "shadow" ? s.pal.shadow : it.color || "#9db4c1", dir = it.vx ?? -22;
    c.fillStyle = col;
    for (let i = 0; i < n; i++) {
      const [fx, fy, a, z, ph] = FLEET[i];
      const x0 = it.x + fx * (it.w || 500), y0 = it.y + fy * (it.h || 240);
      const dx = fl ? x0 - fl.x : 0, dy = fl ? y0 - fl.y : 0, h = Math.hypot(dx, dy) || 1;
      const x = x0 + dir * (t - it.from) + (dx / h) * k * (fl?.dist || 0) + Math.sin(t * 5 + ph) * 5;
      const y = y0 + (dy / h) * k * (fl?.dist || 0) + Math.cos(t * 4 + ph) * 5;
      const base = dir < 0 ? Math.PI : 0;
      c.save(); c.translate(x, y); c.rotate(mix(base, Math.atan2(dy, dx), k)); c.scale((it.size || .65) * z, (it.size || .65) * z); c.fill(FISH); c.restore();
    }
  };
  const FIZZ = (() => { const R = seeded(9); return Array.from({ length: 80 }, () => [(R() - .5) * 92, 4 + R() * 11, R() * TAU]); })();
  K.bubbles = (it, t) => {
    const c = s.c, n = Math.min(it.n || 44, 80), rise = it.rise || 220, last = it.emitTo ?? it.to, life = it.life || 1.5;
    c.strokeStyle = "#e8f8ff"; c.fillStyle = "rgba(223,244,255,.13)"; c.lineWidth = 2;
    for (let i = 0; i < n; i++) {
      const born = mix(it.from, last, i / n), age = t - born;
      if (age < 0 || age > life) continue;
      const [jx, r, wob] = FIZZ[i];
      c.globalAlpha = 1 - age / life;
      c.beginPath(); c.arc(val(it.x, born, 0) + jx + Math.sin(age * 5 + wob) * 12, val(it.y, born, 0) - age * rise, r, 0, TAU); c.fill(); c.stroke();
    }
    c.globalAlpha = 1;
  };
  const STREAK = (() => { const R = seeded(21); return Array.from({ length: 50 }, () => [R(), R(), 60 + R() * 130, .7 + R() * .6]); })();
  /* Lines rushing upward: the feeling of going down. "power" can be keyframed. */
  K.rain = (it, t) => {
    const c = s.c, p = val(it.power, t, 1), H = s.H + 320;
    c.fillStyle = "#d4efff";
    for (const [fx, fy, ln, sp] of STREAK) {
      c.globalAlpha = .05 + .24 * p;
      c.fillRect(fx * s.W, (((fy * H - t * 1700 * sp) % H) + H) % H - 150, 2.6, ln * (.3 + p));
    }
    c.globalAlpha = 1;
  };
  /* Sound clicks: arcs leaving a point. "turn" sets direction in degrees. */
  K.sonic = (it, t) => {
    const c = s.c, sp = it.speed || 1500, a = (it.spread || 34) * RAD, base = (it.turn || 0) * RAD, col = hue(it.color || "sonar"), x = val(it.x, t, 0), y = val(it.y, t, 0);
    c.strokeStyle = col; c.lineCap = "round";
    for (const at of it.clicks || []) {
      const age = t - at;
      if (age < 0 || age > 1.1) continue;
      for (let j = 0; j < 3; j++) {
        c.lineWidth = (it.width || 6) - j * 1.4;
        c.globalAlpha = (1 - age / 1.1) * (1 - j * .24);
        c.beginPath(); c.arc(x, y, Math.max(1, (age - j * .05) * sp), base - a, base + a); c.stroke();
      }
    }
    c.globalAlpha = 1;
  };
  K.shock = (it, t) => {
    const c = s.c, every = it.every || .24, x = val(it.x, t, 0), y = val(it.y, t, 0), col = hue(it.color || "ink");
    c.strokeStyle = col;
    for (let at = it.from; at < t && at < (it.emitTo ?? it.to); at += every) {
      const age = t - at;
      if (age > 1.2) continue;
      c.lineWidth = 7 * (1 - age / 1.2) + 1; c.globalAlpha = (1 - age / 1.2) * .62;
      c.beginPath(); c.arc(x, y, 30 + age * (it.speed || 1250), 0, TAU); c.stroke();
    }
    c.globalAlpha = 1;
  };
  K.radar = (it, t) => {
    const c = s.c, x = it.x ?? 150, y = it.y ?? s.H / 2, R = it.r ?? 1800, a = (it.spread ?? 42) * RAD, col = s.pal.sonar;
    c.save(); c.strokeStyle = col; c.lineWidth = 1.4; c.globalAlpha *= .22;
    for (let i = 1; i <= 6; i++) { c.beginPath(); c.arc(x, y, (R * i) / 6, -a, a); c.stroke(); }
    for (let i = -3; i <= 3; i++) { const q = (i / 3) * a; c.beginPath(); c.moveTo(x, y); c.lineTo(x + Math.cos(q) * R, y + Math.sin(q) * R); c.stroke(); }
    c.restore();
    const sw = Math.sin((t - it.from) * (it.speed || 4.5)) * a;
    c.strokeStyle = alpha(col, .2); c.lineWidth = 12; c.beginPath(); c.moveTo(x, y); c.lineTo(x + Math.cos(sw) * R, y + Math.sin(sw) * R); c.stroke();
    c.strokeStyle = col; c.lineWidth = 3; c.stroke();
  };
})();
